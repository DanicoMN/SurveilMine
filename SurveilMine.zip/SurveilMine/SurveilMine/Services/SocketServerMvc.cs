﻿using Microsoft.AspNetCore.SignalR;
using SuperSimpleTcp;

namespace SurveilMine.Services
{
    public class SocketServerService
    {
        private SimpleTcpServer _server;
        private readonly IHubContext<MessageHub> _hubContext;

        // Déclaration de l'événement qui sera déclenché lorsqu'un message est reçu
        public event Action<string> MessageReceived;

        public SocketServerService(IHubContext<MessageHub> hubContext)
        {
            _server = new SimpleTcpServer("192.168.8.101:8080");
            _server.Events.DataReceived += OnDataReceived;
            _hubContext = hubContext;
        }

        public void Start()
        {
            _server.Start();
        }

        private async void OnDataReceived(object sender, DataReceivedEventArgs e)
        {
            string message = System.Text.Encoding.UTF8.GetString(e.Data);

            // Déclenche l'événement pour notifier les abonnés (par exemple le contrôleur)
            MessageReceived?.Invoke(message);

            // Envoie le message via SignalR aux clients connectés
            await _hubContext.Clients.All.SendAsync("ReceiveMessage", message);
        }

        public void Stop()
        {
            _server.Stop();
        }
    }
}
