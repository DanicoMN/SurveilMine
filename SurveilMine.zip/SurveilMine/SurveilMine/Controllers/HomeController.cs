using Microsoft.AspNetCore.Mvc;

namespace SurveilMine.Controllers
{
    public class HomeController : Controller
    {
        // Action pour la page d'accueil
        public IActionResult Index()
        {
            return View();
        }
    }
}