using Microsoft.AspNetCore.Mvc;
using SurveilMine.Services;
using System.Collections.Concurrent;

namespace SurveilMine.Controllers
{
    public class DashboardController : Controller
    {
        // Action pour la page d'accueil
        private readonly SocketServerService _socketServerService;
        private static ConcurrentQueue<string> _messages = new ConcurrentQueue<string>();

        public DashboardController(SocketServerService socketServerService)
        {
            _socketServerService = socketServerService;
            _socketServerService.MessageReceived += OnMessageReceived;
        }
        public IActionResult Dashboard()
        {
            return View(_messages);
        }
        private void OnMessageReceived(string message)
        {
            _messages.Enqueue(message);
        }
    }
}