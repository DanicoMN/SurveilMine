using Microsoft.AspNetCore.Mvc;

namespace SurveilMine.Controllers;

public class AuthController: Controller
{
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(string username, string password)
    {
        // Validation simplifiée des informations d'identification
        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
        {
            ViewBag.ErrorMessage = "Username and Password cannot be empty.";
            return View();
        }

        // Simuler la vérification avec un utilisateur fictif
        if (username == "MWEMBO" && password == "0038899")
        {
            // Rediriger vers le tableau de bord après la connexion réussie
            return RedirectToAction("Index", "Dashboard");
        }
        else
        {
            ViewBag.ErrorMessage = "Invalid credentials. Please try again.";
            return View();
        }
    }
}