using Microsoft.AspNetCore.Mvc;
using SurveilMine.Models;
using System.Collections.Generic;
using System.Linq;

namespace SurveilMine.Controllers
{
    public class HistoryController : Controller
    {
        // Simule une liste d'alertes historiques pour l'exemple
        private static List<Alert> HistoricalAlerts = new List<Alert>
        {
            new Alert { Id = 1, Title = "Séisme détecté", Severity = "Critique", Description = "Un séisme de magnitude 4.2 a été détecté.", Timestamp = DateTime.Now.AddDays(-1), Confirmed = true },
            new Alert { Id = 2, Title = "Vibration anormale", Severity = "Modérée", Description = "Vibration inhabituelle détectée en Zone B.", Timestamp = DateTime.Now.AddDays(-2), Confirmed = true },
            new Alert { Id = 3, Title = "Capteur reconnecté", Severity = "Mineure", Description = "Capteur en Zone C reconnecté.", Timestamp = DateTime.Now.AddDays(-3), Confirmed = true }
        };

        // Affiche la liste des alertes historiques
        public IActionResult Index()
        {
            // Trier les alertes par date (plus récentes en premier)
            var sortedAlerts = HistoricalAlerts.OrderByDescending(a => a.Timestamp).ToList();
            return View(sortedAlerts);
        }

        // Affiche les détails d'une alerte historique spécifique
        public IActionResult Details(int id)
        {
            var alert = HistoricalAlerts.FirstOrDefault(a => a.Id == id);
            if (alert == null)
            {
                return NotFound();
            }
            return View(alert);
        }
    }
}