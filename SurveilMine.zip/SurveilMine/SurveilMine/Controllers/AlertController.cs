using Microsoft.AspNetCore.Mvc;
using SurveilMine.Models; // Assurez-vous d'avoir un modèle pour les alertes

namespace SurveilMine.Controllers
{
    public class AlertController : Controller
    {
        // Simule une liste d'alertes pour l'exemple
        private static List<Alert> Alerts = new List<Alert>
        {
            new Alert { Id = 1, Title = "Séisme détecté", Severity = "Critique", Description = "Un séisme de magnitude 4.2 a été détecté.", Timestamp = DateTime.Now.AddMinutes(-10) },
            new Alert { Id = 2, Title = "Vibration anormale", Severity = "Modérée", Description = "Une vibration inhabituelle a été détectée dans la Zone B.", Timestamp = DateTime.Now.AddMinutes(-30) },
            new Alert { Id = 3, Title = "Capteur déconnecté", Severity = "Mineure", Description = "Le capteur de Zone C est hors ligne.", Timestamp = DateTime.Now.AddMinutes(-45) }
        };

        // Affiche la liste des alertes
        public IActionResult Index()
        {
            return View(Alerts);
        }

        // Affiche les détails d'une alerte spécifique
        public IActionResult Details(int id)
        {
            var alert = Alerts.FirstOrDefault(a => a.Id == id);
            if (alert == null)
            {
                return NotFound();
            }
            return View(alert);
        }

        // Permet de confirmer ou ignorer une alerte (action simulée)
        [HttpPost]
        public IActionResult Confirm(int id)
        {
            var alert = Alerts.FirstOrDefault(a => a.Id == id);
            if (alert != null)
            {
                // Logique pour confirmer l'alerte
                alert.Confirmed = true;
            }
            return RedirectToAction(nameof(Index));
        }

        // Permet de supprimer une alerte (action simulée)
        [HttpPost]
        public IActionResult Delete(int id)
        {
            var alert = Alerts.FirstOrDefault(a => a.Id == id);
            if (alert != null)
            {
                Alerts.Remove(alert);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
