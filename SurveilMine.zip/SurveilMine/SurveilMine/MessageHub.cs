﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace SurveilMine
{
    public class MessageHub : Hub
    {
        public async Task SendMessage(string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", message);
        }
    }
}
