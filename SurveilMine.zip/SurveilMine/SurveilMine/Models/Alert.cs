using System;

namespace SurveilMine.Models
{
    public class Alert
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Severity { get; set; } // Critique, Modérée, Mineure
        public string Description { get; set; }
        public DateTime Timestamp { get; set; }
        public bool Confirmed { get; set; } = false;
    }
}