using SurveilMine;
using SurveilMine.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Register the SocketServerService
builder.Services.AddSingleton<SocketServerService>();
builder.Services.AddSignalR();  // Add SignalR

var app = builder.Build();

var socketServer = app.Services.GetRequiredService<SocketServerService>();
socketServer.Start();



// Configure the HTTP request pipeline.


app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Auth}/{action=Login}/{id?}");
app.MapHub<MessageHub>("/messageHub");  // Map SignalR hub

app.Run();